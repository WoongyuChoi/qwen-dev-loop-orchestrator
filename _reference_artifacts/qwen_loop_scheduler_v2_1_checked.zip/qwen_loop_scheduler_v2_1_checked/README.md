# Qwen Loop Scheduler v3

Windows 11 + Windows PowerShell 5.1 기준으로 한글 깨짐을 줄이기 위해 응답 본문을 raw byte로 읽어서 UTF-8로 직접 디코딩합니다.

## 빠른 테스트

```cmd
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\qwen-loop.ps1 -DryRun
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\qwen-loop.ps1 -MaxRuns 1 -IntervalSeconds 5
```

성공하면 `run-qwen-loop.bat`를 실행하세요.

## 8510 provider 사용

```cmd
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\qwen-loop.ps1 -ProviderName "qwen3.6-agent_test" -MaxRuns 1
```

## Authorization 헤더 없이 테스트

```cmd
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\qwen-loop.ps1 -MaxRuns 1 -NoAuthHeader
```


## 검증 모드

settings.json의 envKey 선택, API key source, Authorization 헤더 전송 여부, endpoint 후보만 확인하려면:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\qwen-loop.ps1 -DryRun
```

서버로 접속할 때 Windows가 선택하는 로컬 SourceAddress까지 확인하려면:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\qwen-loop.ps1 -DryRun -NetworkCheck
```

API 서버가 Authorization 헤더를 싫어하면:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\qwen-loop.ps1 -Once -NoAuthorizationHeader
```
