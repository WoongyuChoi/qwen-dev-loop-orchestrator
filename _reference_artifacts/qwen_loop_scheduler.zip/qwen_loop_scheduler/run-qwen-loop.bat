@echo off
chcp 65001 >nul
setlocal

REM Qwen self-questioning loop runner
REM Stop: press Ctrl+C, then Y

set "SCRIPT_DIR=%~dp0"

powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%qwen-loop.ps1" ^
  -SettingsPath "C:\Users\KB099\.qwen\settings.json" ^
  -IntervalSeconds 600 ^
  -MaxTokens 8192 ^
  -Temperature 0.35 ^
  -TimeoutSec 900 ^
  -WorkDir "%SCRIPT_DIR%qwen-loop-data" ^
  -SeedFile "%SCRIPT_DIR%seed_prompt.txt" ^
  -ContextListFile "%SCRIPT_DIR%context_files.txt"

pause
