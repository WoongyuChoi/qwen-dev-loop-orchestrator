﻿# Qwen Loop Scheduler

`C:\Users\KB099\.qwen\settings.json`에 있는 Qwen Code 설정을 읽어서, OpenAI-compatible API로 10분마다 질문을 던지는 Windows용 루프 스크립트입니다.

## 파일

- `run-qwen-loop.bat`: 실행 파일
- `qwen-loop.ps1`: 실제 PowerShell 루프
- `seed_prompt.txt`: 첫 질문
- `context_files.txt`: 매 요청마다 같이 첨부할 문서 경로 목록
- `qwen-loop-data/next_question.txt`: 다음 루프 질문 저장 위치
- `qwen-loop-data/transcript.md`: 질문/답변 누적 로그
- `qwen-loop-data/transcript.jsonl`: JSONL 로그
- `qwen-loop-data/error.log`: 오류 로그

## 실행

1. 이 폴더를 원하는 위치에 풉니다.
2. `seed_prompt.txt`를 원하는 첫 질문으로 수정합니다.
3. 필요하면 `context_files.txt`에 프로젝트 문서 경로를 추가합니다.
4. `run-qwen-loop.bat`를 더블클릭하거나 cmd에서 실행합니다.
5. 종료는 콘솔에서 `Ctrl+C`를 누릅니다.

## 기본값

- settings path: `C:\Users\KB099\.qwen\settings.json`
- interval: 600초
- max_tokens: 8192
- temperature: 0.35

## 주의

이 루프는 모델의 가중치를 학습시키지는 않습니다. 대신 질문/답변 로그를 계속 쌓아 프로젝트 분석 문서나 RAG 자료로 재활용할 수 있게 해줍니다.
