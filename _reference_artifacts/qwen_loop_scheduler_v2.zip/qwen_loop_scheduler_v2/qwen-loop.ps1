﻿param(
    [string]$SettingsPath = "$env:USERPROFILE\.qwen\settings.json",
    [string]$ProviderName = "",
    [string]$ModelName = "",
    [string]$SeedFile = "$PSScriptRoot\seed_prompt.txt",
    [string]$ContextListFile = "$PSScriptRoot\context_files.txt",
    [string]$WorkDir = "$PSScriptRoot\qwen-loop-data",
    [int]$IntervalSeconds = 600,
    [int]$MaxTokens = 8192,
    [double]$Temperature = 0.35,
    [int]$TimeoutSec = 900,
    [int]$MaxContextChars = 30000,
    [int]$IncludePreviousAnswerChars = 12000,
    [int]$MaxRuns = 0,
    [switch]$NoAuthHeader,
    [switch]$DryRun
)

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"
[System.Net.ServicePointManager]::Expect100Continue = $false
try { [Console]::InputEncoding = [System.Text.Encoding]::UTF8 } catch {}
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}
$OutputEncoding = [System.Text.Encoding]::UTF8

function Write-Utf8File($Path, $Text) {
    $dir = Split-Path -Parent $Path
    if ($dir -and !(Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    [System.IO.File]::WriteAllText($Path, [string]$Text, [System.Text.UTF8Encoding]::new($false))
}

function Append-Utf8File($Path, $Text) {
    $dir = Split-Path -Parent $Path
    if ($dir -and !(Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    [System.IO.File]::AppendAllText($Path, [string]$Text, [System.Text.UTF8Encoding]::new($false))
}

function Normalize-ApiKey($value) {
    if ($null -eq $value) { return "dummy" }
    $v = [string]$value
    $v = $v.Trim()
    if ([string]::IsNullOrWhiteSpace($v)) { return "dummy" }
    if ($v -eq '""' -or $v -eq '\"\"' -or $v -eq 'not-needed') { return "dummy" }
    return $v
}

function Expand-PathInput([string]$PathText) {
    if ([string]::IsNullOrWhiteSpace($PathText)) { return $PathText }
    $p = [Environment]::ExpandEnvironmentVariables($PathText.Trim())
    if ($p -eq "~") { return $env:USERPROFILE }
    if ($p.StartsWith("~\") -or $p.StartsWith("~/")) {
        return (Join-Path $env:USERPROFILE $p.Substring(2))
    }
    return $p
}

function Get-JsonProperty($obj, [string]$name) {
    if ($null -eq $obj) { return $null }
    $prop = $obj.PSObject.Properties | Where-Object { $_.Name -eq $name } | Select-Object -First 1
    if ($prop) { return $prop.Value }
    return $null
}

function Get-SettingsProvider($settings, [string]$providerName, [string]$modelNameOverride) {
    $selectedType = "openai"
    $security = Get-JsonProperty $settings "security"
    $auth = Get-JsonProperty $security "auth"
    $selected = Get-JsonProperty $auth "selectedType"
    if (-not [string]::IsNullOrWhiteSpace([string]$selected)) { $selectedType = [string]$selected }

    $modelProviders = Get-JsonProperty $settings "modelProviders"
    $providerListRaw = Get-JsonProperty $modelProviders $selectedType
    if ($null -eq $providerListRaw) {
        throw "settings.json에서 modelProviders.$selectedType 항목을 찾지 못했습니다."
    }

    $providers = @($providerListRaw) | Where-Object { $null -ne $_ }
    if ($providers.Count -eq 0) {
        throw "settings.json의 modelProviders.$selectedType 목록이 비어 있습니다."
    }

    $target = $providerName
    $model = Get-JsonProperty $settings "model"
    $settingsModelName = Get-JsonProperty $model "name"
    if ([string]::IsNullOrWhiteSpace($target) -and -not [string]::IsNullOrWhiteSpace([string]$settingsModelName)) {
        $target = [string]$settingsModelName
    }

    $provider = $null
    if (-not [string]::IsNullOrWhiteSpace($target)) {
        $provider = $providers | Where-Object {
            ([string](Get-JsonProperty $_ "name")) -eq $target -or ([string](Get-JsonProperty $_ "id")) -eq $target
        } | Select-Object -First 1
        if ($null -eq $provider) {
            Write-Host "[WARN] provider/model '$target'을 찾지 못해서 첫 번째 provider를 사용합니다." -ForegroundColor Yellow
        }
    }
    if ($null -eq $provider) { $provider = $providers | Select-Object -First 1 }

    $providerNameValue = [string](Get-JsonProperty $provider "name")
    $providerId = [string](Get-JsonProperty $provider "id")
    $modelId = if ([string]::IsNullOrWhiteSpace($modelNameOverride)) { $providerId } else { $modelNameOverride }
    if ([string]::IsNullOrWhiteSpace($modelId)) { $modelId = $providerNameValue }

    $baseUrl = [string](Get-JsonProperty $provider "baseUrl")
    if ([string]::IsNullOrWhiteSpace($baseUrl)) { throw "선택된 provider에 baseUrl이 없습니다." }

    $apiKey = $null
    $envKey = [string](Get-JsonProperty $provider "envKey")
    if (-not [string]::IsNullOrWhiteSpace($envKey)) {
        $apiKey = [Environment]::GetEnvironmentVariable($envKey)
        if ([string]::IsNullOrWhiteSpace($apiKey)) {
            $settingsEnv = Get-JsonProperty $settings "env"
            $apiKey = Get-JsonProperty $settingsEnv $envKey
        }
    }

    return [PSCustomObject]@{
        Type = $selectedType
        ProviderName = $providerNameValue
        ModelId = $modelId
        BaseUrl = $baseUrl.TrimEnd('/')
        ApiKey = (Normalize-ApiKey $apiKey)
    }
}

function Get-EndpointCandidates([string]$baseUrl) {
    $b = $baseUrl.TrimEnd('/')
    $candidates = New-Object System.Collections.Generic.List[string]
    if ($b -match '/v1$') {
        $candidates.Add("$b/chat/completions")
    } else {
        $candidates.Add("$b/v1/chat/completions")
        $candidates.Add("$b/chat/completions")
    }
    return $candidates | Select-Object -Unique
}

function Read-TextFileUtf8([string]$Path) {
    return [System.IO.File]::ReadAllText($Path, [System.Text.Encoding]::UTF8)
}

function Read-ContextBundle([string]$listFile, [int]$maxChars) {
    if (!(Test-Path $listFile)) { return "" }

    $paths = Get-Content -Path $listFile -Encoding UTF8 |
        ForEach-Object { ($_ -replace '^\uFEFF', '').Trim() } |
        Where-Object { $_ -and -not $_.StartsWith('#') }

    if (@($paths).Count -eq 0) { return "" }

    $bundleParts = New-Object System.Collections.Generic.List[string]
    $used = 0
    foreach ($p0 in @($paths)) {
        $p = Expand-PathInput $p0
        try {
            $resolved = Resolve-Path $p -ErrorAction Stop | Select-Object -First 1
            if ((Get-Item $resolved.Path).PSIsContainer) {
                $bundleParts.Add("`n--- CONTEXT DIRECTORY SKIPPED: $($resolved.Path) ---`n파일 경로를 직접 지정하세요.`n")
                continue
            }
            $raw = Read-TextFileUtf8 $resolved.Path
            $remaining = $maxChars - $used
            if ($remaining -le 0) { break }
            if ($raw.Length -gt $remaining) { $raw = $raw.Substring(0, $remaining) + "`n...[context truncated]..." }
            $bundleParts.Add("`n--- CONTEXT FILE: $($resolved.Path) ---`n$raw`n--- END CONTEXT FILE ---`n")
            $used += $raw.Length
        } catch {
            $bundleParts.Add("`n--- CONTEXT FILE LOAD FAILED: $p0 / $($_.Exception.Message) ---`n")
        }
    }
    return ($bundleParts -join "`n")
}

function Truncate-Text([string]$text, [int]$maxChars) {
    if ([string]::IsNullOrWhiteSpace($text)) { return "" }
    if ($maxChars -le 0) { return "" }
    if ($text.Length -le $maxChars) { return $text }
    return $text.Substring(0, $maxChars) + "`n...[previous answer truncated]..."
}

function Extract-NextQuestion([string]$content) {
    $lines = $content -split "`r?`n" | ForEach-Object { $_.Trim() } | Where-Object { $_ -ne "" }
    foreach ($line in $lines) {
        if ($line -match '^NEXT_QUESTION\s*[:：]\s*(.+)$') {
            return $Matches[1].Trim()
        }
    }
    if (@($lines).Count -gt 0) {
        $candidate = [string]$lines[0]
        $candidate = $candidate -replace '^[-#\d\.\s]+', ''
        $candidate = $candidate -replace '^다음\s*질문\s*[:：]\s*', ''
        if ($candidate.Length -gt 300) { $candidate = $candidate.Substring(0, 300) }
        if (-not [string]::IsNullOrWhiteSpace($candidate)) { return $candidate.Trim() }
    }
    return "이전 답변을 바탕으로 Java Spring Boot와 React 개발 관점에서 더 깊게 분석해야 할 다음 질문을 만들어줘."
}

function Invoke-JsonPostUtf8($Uri, $Headers, $BodyObject, [int]$TimeoutSec) {
    $json = $BodyObject | ConvertTo-Json -Depth 50 -Compress
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)

    $request = [System.Net.HttpWebRequest][System.Net.WebRequest]::Create($Uri)
    $request.Method = "POST"
    $request.Accept = "application/json"
    $request.ContentType = "application/json; charset=utf-8"
    $request.Timeout = $TimeoutSec * 1000
    $request.ReadWriteTimeout = $TimeoutSec * 1000
    $request.ContentLength = $bytes.Length

    foreach ($key in $Headers.Keys) {
        if ($key -eq "Accept") { $request.Accept = [string]$Headers[$key]; continue }
        if ($key -eq "Content-Type") { $request.ContentType = [string]$Headers[$key]; continue }
        $request.Headers[$key] = [string]$Headers[$key]
    }

    $reqStream = $request.GetRequestStream()
    try { $reqStream.Write($bytes, 0, $bytes.Length) } finally { $reqStream.Dispose() }

    try {
        $response = [System.Net.HttpWebResponse]$request.GetResponse()
        try {
            $reader = New-Object System.IO.StreamReader($response.GetResponseStream(), [System.Text.Encoding]::UTF8)
            try { $text = $reader.ReadToEnd() } finally { $reader.Dispose() }
        } finally {
            $response.Dispose()
        }
        if ([string]::IsNullOrWhiteSpace($text)) { throw "빈 응답을 받았습니다." }
        return $text | ConvertFrom-Json
    } catch [System.Net.WebException] {
        $errText = $_.Exception.Message
        if ($_.Exception.Response) {
            try {
                $errResp = [System.Net.HttpWebResponse]$_.Exception.Response
                $reader = New-Object System.IO.StreamReader($errResp.GetResponseStream(), [System.Text.Encoding]::UTF8)
                try { $errText = $reader.ReadToEnd() } finally { $reader.Dispose(); $errResp.Dispose() }
            } catch {}
        }
        throw "HTTP 호출 실패: $errText"
    }
}

function Invoke-QwenChat($providerInfo, [string]$systemPrompt, [string]$userPrompt) {
    $headers = @{ "Accept" = "application/json" }
    if (-not $NoAuthHeader) {
        $headers["Authorization"] = "Bearer $($providerInfo.ApiKey)"
    }

    $bodyObj = [ordered]@{
        model = $providerInfo.ModelId
        messages = @(
            @{ role = "system"; content = $systemPrompt },
            @{ role = "user"; content = $userPrompt }
        )
        temperature = $Temperature
        max_tokens = $MaxTokens
        stream = $false
    }

    $lastError = $null
    foreach ($endpoint in (Get-EndpointCandidates $providerInfo.BaseUrl)) {
        try {
            Write-Host "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] POST $endpoint" -ForegroundColor Cyan
            $resp = Invoke-JsonPostUtf8 -Uri $endpoint -Headers $headers -BodyObject $bodyObj -TimeoutSec $TimeoutSec
            if ($resp.choices -and $resp.choices.Count -gt 0) {
                $choice = $resp.choices[0]
                if ($choice.message -and $choice.message.content) { return [string]$choice.message.content }
                if ($choice.text) { return [string]$choice.text }
            }
            return ($resp | ConvertTo-Json -Depth 50)
        } catch {
            $lastError = $_.Exception.Message
            Write-Host "Endpoint failed: $endpoint" -ForegroundColor Yellow
            Write-Host $lastError -ForegroundColor Yellow
        }
    }
    throw "모든 endpoint 호출 실패. 마지막 오류: $lastError"
}

$SettingsPath = Expand-PathInput $SettingsPath
$SeedFile = Expand-PathInput $SeedFile
$ContextListFile = Expand-PathInput $ContextListFile
$WorkDir = Expand-PathInput $WorkDir

if (!(Test-Path $SettingsPath)) {
    throw "settings.json을 찾지 못했습니다: $SettingsPath"
}

New-Item -ItemType Directory -Force -Path $WorkDir | Out-Null
$settings = Read-TextFileUtf8 $SettingsPath | ConvertFrom-Json
$providerInfo = Get-SettingsProvider $settings $ProviderName $ModelName

$nextQuestionPath = Join-Path $WorkDir "next_question.txt"
$lastAnswerPath = Join-Path $WorkDir "last_answer.txt"
$transcriptPath = Join-Path $WorkDir "transcript.md"
$jsonlPath = Join-Path $WorkDir "transcript.jsonl"
$errorLogPath = Join-Path $WorkDir "error.log"

$seedQuestion = "Java Spring Boot와 React 프로젝트를 장기적으로 개선하기 위해, 먼저 백엔드 구조와 프론트엔드 연동 구조를 어떤 순서로 분석해야 하는지 알려줘."
if (Test-Path $SeedFile) {
    $seedQuestion = (Read-TextFileUtf8 $SeedFile).Trim()
}
if (!(Test-Path $nextQuestionPath)) {
    Write-Utf8File $nextQuestionPath $seedQuestion
}

$systemPrompt = @"
너는 Java Spring Boot, MyBatis/JPA, React, TypeScript, 운영 배포 환경을 함께 보는 시니어 개발 아키텍트다.

매 응답은 반드시 아래 규칙을 지킨다.

1. 첫 번째 줄은 반드시 다음 형식 한 줄로만 작성한다.
NEXT_QUESTION: 여기에 다음 루프에서 물어볼 구체적인 후속 질문을 한 문장으로 작성

2. 두 번째 줄부터는 현재 질문에 대한 답변을 한국어로 자세히 작성한다.
3. 답변은 실무 개발자가 바로 사용할 수 있게 구체적으로 작성한다.
4. Java Spring Boot와 React 관점에서 구조, 위험요소, 테스트, 리팩토링, 성능, 보안, 유지보수성을 같이 고려한다.
5. 코드베이스 내용이 제공되지 않은 경우에는 추측을 확정처럼 말하지 말고, 확인해야 할 파일과 명령을 제시한다.
6. 다음 질문은 현재 답변에서 가장 중요한 미해결 지점이나 더 깊게 파고들 가치가 있는 지점으로 만든다.
7. 토큰을 아끼기 위해 너무 짧게 답하지 말고, 가능한 한 깊이 있는 분석, 체크리스트, 예시, 반례, 검증 방법을 포함한다.
"@

Write-Host "=== Qwen Loop Scheduler v2 ===" -ForegroundColor Green
Write-Host "SettingsPath : $SettingsPath"
Write-Host "Provider     : $($providerInfo.ProviderName)"
Write-Host "BaseUrl      : $($providerInfo.BaseUrl)"
Write-Host "Model        : $($providerInfo.ModelId)"
Write-Host "Endpoints    : $((Get-EndpointCandidates $providerInfo.BaseUrl) -join ', ')"
Write-Host "IntervalSec  : $IntervalSeconds"
Write-Host "MaxTokens    : $MaxTokens"
Write-Host "WorkDir      : $WorkDir"
Write-Host "MaxRuns      : $MaxRuns (0 = infinite)"
Write-Host "Stop         : Ctrl+C"
Write-Host "===============================" -ForegroundColor Green

if ($DryRun) {
    Write-Host "DryRun mode: 설정 파싱만 확인하고 종료합니다." -ForegroundColor Cyan
    exit 0
}

$runCount = 0
while ($true) {
    $runCount++
    $started = Get-Date
    try {
        $question = (Read-TextFileUtf8 $nextQuestionPath).Trim()
        if ([string]::IsNullOrWhiteSpace($question)) { $question = $seedQuestion }

        $contextBundle = Read-ContextBundle $ContextListFile $MaxContextChars
        $previousAnswer = ""
        if (Test-Path $lastAnswerPath) {
            $previousAnswer = Truncate-Text ((Read-TextFileUtf8 $lastAnswerPath).Trim()) $IncludePreviousAnswerChars
        }

        $userPrompt = @"
현재 루프 번호: $runCount

현재 루프 질문:
$question

직전 답변 발췌:
$previousAnswer

공통 컨텍스트:
$contextBundle

요청:
위 질문에 답변해줘.
반드시 첫 번째 줄에는 NEXT_QUESTION: 으로 시작하는 다음 후속 질문을 한 줄로 작성하고, 그 뒤에 현재 질문에 대한 상세 답변을 작성해줘.
"@

        Write-Host "`n[$($started.ToString('yyyy-MM-dd HH:mm:ss'))] RUN #$runCount QUESTION:" -ForegroundColor Green
        Write-Host $question

        $answer = Invoke-QwenChat $providerInfo $systemPrompt $userPrompt
        $nextQuestion = Extract-NextQuestion $answer
        $ended = Get-Date

        Write-Utf8File $nextQuestionPath $nextQuestion
        Write-Utf8File $lastAnswerPath $answer

        $md = @"

---

# $($started.ToString('yyyy-MM-dd HH:mm:ss')) / Run #$runCount

## Question

$question

## Next Question

$nextQuestion

## Answer

$answer

"@
        Append-Utf8File $transcriptPath $md

        $record = [ordered]@{
            started = $started.ToString("o")
            ended = $ended.ToString("o")
            run = $runCount
            provider = $providerInfo.ProviderName
            baseUrl = $providerInfo.BaseUrl
            model = $providerInfo.ModelId
            question = $question
            nextQuestion = $nextQuestion
            answer = $answer
        }
        Append-Utf8File $jsonlPath (($record | ConvertTo-Json -Compress -Depth 50) + "`n")

        Write-Host "`nNEXT QUESTION:" -ForegroundColor Magenta
        Write-Host $nextQuestion
        Write-Host "`nSaved:" -ForegroundColor DarkGreen
        Write-Host "- $nextQuestionPath"
        Write-Host "- $lastAnswerPath"
        Write-Host "- $transcriptPath"
        Write-Host "- $jsonlPath"
    } catch {
        $msg = "[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] RUN #$runCount ERROR: $($_.Exception.Message)`n$($_.ScriptStackTrace)`n"
        Append-Utf8File $errorLogPath $msg
        Write-Host $msg -ForegroundColor Red
    }

    if ($MaxRuns -gt 0 -and $runCount -ge $MaxRuns) {
        Write-Host "MaxRuns=$MaxRuns reached. 종료합니다." -ForegroundColor Cyan
        break
    }

    Write-Host "`nWaiting $IntervalSeconds seconds... Ctrl+C to stop." -ForegroundColor DarkGray
    Start-Sleep -Seconds $IntervalSeconds
}
