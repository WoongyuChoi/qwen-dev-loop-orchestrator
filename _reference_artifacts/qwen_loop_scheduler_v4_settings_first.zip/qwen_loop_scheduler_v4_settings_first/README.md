# Qwen Loop Scheduler v4 - Settings First

이 버전은 C:\Users\KB099\.qwen\settings.json을 최대한 그대로 활용하는 방향으로 고친 버전입니다.

## 더블클릭 실행 순서

1. `01_CHECK_SETTINGS_DOUBLECLICK.bat`  
   API 호출 없이 settings.json을 어떻게 해석했는지 확인합니다.

2. `02_RUN_ONCE_TEST_DOUBLECLICK.bat`  
   실제 API 호출을 1회만 실행합니다.

3. `03_RUN_LOOP_10MIN_DOUBLECLICK.bat` 또는 `run-qwen-loop.bat`  
   10분마다 계속 호출합니다. 종료는 Ctrl+C입니다.

4. `05_OPEN_LOG_FOLDER.bat`  
   로그 폴더를 엽니다.

## settings.json 활용 방식

- `security.auth.selectedType`으로 provider type을 선택합니다.
- `model.name`으로 provider를 찾습니다.
- `modelProviders.<type>[].id/name/baseUrl/envKey/generationConfig`를 사용합니다.
- `envKey` 값은 Windows 환경변수에서 먼저 찾고, 없으면 settings.json의 `env` 항목에서 찾습니다.
- API Key는 dummy로 바꾸지 않습니다. 찾은 값을 Authorization 헤더에 그대로 넣습니다.
- `general.outputLanguage`는 system prompt에 반영됩니다.
- `permissions.allow`는 system prompt에 참고 정보로 포함됩니다.
- `provider.generationConfig`는 기본 모드에서 request body에 포함됩니다.
- `qwen_client_settings` 메타데이터를 request body에 포함합니다.
- 클라이언트 PC 이름, 사용자명, TCP 연결 기준 local IP를 `X-Qwen-Loop-*` 헤더로 보냅니다.

## 로그 파일

실행 후 `qwen-loop-data` 폴더에 아래 파일이 생성됩니다.

- `settings_effective_summary.json`
- `last_request_headers.json`
- `last_request_body.json`
- `next_question.txt`
- `last_turn.txt`
- `transcript.md`
- `transcript.jsonl`
- `error.log`

`last_request_headers.json`은 Authorization 값을 기본적으로 마스킹해서 저장합니다. 실제 전송은 마스킹하지 않습니다.
민감값까지 로그로 확인하려면 ps1에 `-LogSensitive`를 붙이면 되지만 일반 사용에서는 권장하지 않습니다.

## 서버가 extra body field를 거부할 때

기본 모드는 settings 메타데이터와 generationConfig를 request body에 넣습니다. 일부 OpenAI-compatible 서버가 unknown field를 거부하면 `04_RUN_LOOP_10MIN_COMPAT_BODY_IF_SERVER_REJECTS.bat`를 사용하세요. 이 모드는 body를 표준 OpenAI Chat Completions 형식에 가깝게 줄이지만, header와 system prompt에는 settings 정보를 계속 반영합니다.
